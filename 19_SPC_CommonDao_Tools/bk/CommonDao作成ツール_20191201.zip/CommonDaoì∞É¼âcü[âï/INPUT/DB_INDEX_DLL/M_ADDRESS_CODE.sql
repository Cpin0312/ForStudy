/**********************************************************/
/*     TABLE NAME: M_ADDRESS_CODE                         */
/*     テーブル名：住所コードマスタ                       */
/**********************************************************/
/* PRIMARY KEY */
ALTER TABLE M_ADDRESS_CODE
 ADD CONSTRAINT PK_M_ADDRESS_CODE PRIMARY KEY(CD_ADS);


